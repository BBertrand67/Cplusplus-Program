//Brian Bertrand
//Project 2

#include <iostream>
#include <iomanip>

using namespace std;

#include "Account.h"

int main()
{
    Account myAccount;
    
    myAccount.getUserInput();
    myAccount.outputAccountDataWithoutDeposits();
    myAccount.outputAccountDataWithDeposits();
    
    return 0;
}