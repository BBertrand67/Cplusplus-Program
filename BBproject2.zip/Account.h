//Brian Bertrand
//Project 2

#include <iostream>
#include <iomanip>

using namespace std;


class Account
{
private:
   float m_initialInvestment;
   float m_monthlyDeposit;
   float m_annualInterest;
   float m_numberYears;
   float m_numberMonths;
   
   float m_totalAmount;
   float m_interestAmount;
   float m_yearTotalInterest;
   
public:

    Account(void)
    {
        // nothing to do
    }
    
    void getUserInput(void)
    {
        //Get data from user
        cout << "********************************\n";
        cout << "********** Data Input **********\n";
        cout << "Initial Investment Amount: $";
        cin >> m_initialInvestment;
        cout << "Monthly Deposit: $";
        cin >> m_monthlyDeposit;
        cout << "Annual Interest: %";
        cin >> m_annualInterest;
        cout << "Number of years: ";
        cin >> m_numberYears;
        m_numberMonths = m_numberYears * 12;
    }
    
    void outputAccountDataWithoutDeposits(void)
    {
        //Set total amount to initial investment to be updated
        float totalAmount = m_initialInvestment;

        //Display year data without monthly deposits
        cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
        cout << "==============================================================\n";
        cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
        cout << "--------------------------------------------------------------\n";

        for (int i = 0; i < m_numberYears; i++)
        {
            //Calculate yearly interest
            float interestAmount = (totalAmount) * ((m_annualInterest / 100));

            //Calculate year end total
            totalAmount = totalAmount + interestAmount;

            //Print results to table showcasing only two decimal points
            cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestAmount << "\n";
        }
    }
    
    void outputAccountDataWithDeposits(void)
    {
        //Set total amount to initial investment to be updated
        float totalAmount = m_initialInvestment;

        //Display year data with monthly deposits
        cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
        cout << "==============================================================\n";
        cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
        cout << "--------------------------------------------------------------\n";

        for (int i = 0; i < m_numberYears; i++)
        {
            //Set yearly interest to zero at the start of the year
            float yearTotalInterest = 0;

            for (int j = 0; j < 12; j++)
            {
                //Calculate monthly interest
                float interestAmount = (totalAmount + m_monthlyDeposit) * ((m_annualInterest / 100) / 12);

                //Calculate month end interest
                yearTotalInterest = yearTotalInterest + interestAmount;

                //Calculate month end total
                totalAmount = totalAmount + m_monthlyDeposit + interestAmount;
            }

            //Print results to table showcasing only two decimal points
            cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << setw(20) << " $" << yearTotalInterest << "\n";
        }
    }
};

